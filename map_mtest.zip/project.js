function menuComponent() {
    return {
        menu: { top: [], bottom: [] },
        content: '',
        pageTitle: '',
        activeSlug: '',
        includeFile: null,
        dynamicModule: null,
        loadedHtml: '',

        async init() {
            const res = await fetch('get_menu_data.php');
            this.menu = await res.json();
        },

        async loadPage(slug) {
            this.activeSlug = slug;
            this.pageTitle = '';
            this.loadedHtml = 'Lade Inhalt...';

            try {
                const res = await fetch('get_page_content.php?slug=' + encodeURIComponent(slug));
                const data = await res.json();
                this.pageTitle = data.titel || '';
                this.includeFile = data.include_file || null;
                this.dynamicModule = data.js_module || null;
                this.loadedHtml = data.inhalt || '';

                // Falls ein JS-Modul erforderlich ist, lade es dynamisch
                if (this.dynamicModule) {
                    await this.loadComponentScript(this.dynamicModule);
                }

                await this.$nextTick();
            } catch (err) {
                console.error(err);
                this.loadedHtml = 'Fehler beim Laden des Inhalts.';
            }
        },

        async loadComponentScript(componentName) {
            const scriptPath = `components/${componentName}.js`;
            if (!window[componentName]) {
                return new Promise((resolve, reject) => {
                    const script = document.createElement('script');
                    script.src = scriptPath;
                    script.onload = resolve;
                    script.onerror = () => {
                        console.error(`Fehler beim Laden von ${scriptPath}`);
                        reject();
                    };
                    document.head.appendChild(script);
                });
            }
        }
    };
}
