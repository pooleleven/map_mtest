<?php
// global_vars.inc.php sollte deine Datenbankverbindung ($conn) bereitstellen
include 'global_vars.inc.php';

header('Content-Type: application/json; charset=utf-8');

$stmt = $conn->prepare("SELECT id, parent_id, position, label, slug, icon_url, css_class, target_type FROM menu_items ORDER BY position ASC, parent_id ASC, sort_order ASC");
$stmt->execute();
$result = $stmt->get_result();

$itemsByPosition = [
    1 => [], // Für Hauptmenü (Position 1)
    2 => []  // Für untere Menüleiste (Position 2)
];

while ($row = $result->fetch_assoc()) {
    // Stellen Sie sicher, dass die Position gültig ist, bevor Sie sie hinzufügen
    if (isset($itemsByPosition[$row['position']])) {
        $itemsByPosition[$row['position']][] = $row;
    }
}

// Funktion zum Aufbau der hierarchischen Menüstruktur
function buildTree(array &$elements, $parentId = NULL) {
    $branch = [];
    foreach ($elements as $key => $element) { // Iteriere mit Schlüssel, um unset zu ermöglichen
        if ($element['parent_id'] == $parentId) {
            $children = buildTree($elements, $element['id']);
            if ($children) {
                $element['children'] = array_values($children); // array_values für sauberes JSON
            }
            $branch[$element['id']] = $element;
            // Optional: Element aus dem Array entfernen, um erneute Verarbeitung zu vermeiden
            // Dies kann bei sehr großen Bäumen die Performance verbessern, ist aber nicht immer notwendig
            // und kann bei bestimmten foreach-Iterationen zu unerwartetem Verhalten führen,
            // wenn das Array während der Iteration verändert wird.
            // Für die meisten Menügrößen ist es ohne unset in Ordnung.
            // unset($elements[$key]);
        }
    }
    return $branch;
}

$mainMenuTree = buildTree($itemsByPosition[1], NULL);
$secondaryMenuTree = buildTree($itemsByPosition[2], NULL);

// Gib beide Menübäume als ein JSON-Objekt zurück
echo json_encode([
    'mainMenu' => array_values($mainMenuTree),
    'secondaryMenu' => array_values($secondaryMenuTree)
]);

$stmt->close();
$conn->close();
?>