<?php
include 'global_vars.inc.php';

header('Content-Type: text/html; charset=utf-8'); // Stellt sicher, dass HTML korrekt gesendet wird

$slug = $_GET['slug'] ?? 'seite1'; // Standardwert, falls kein Slug übergeben wird

// SQL-Abfrage vorbereiten und ausführen
$stmt = $conn->prepare("SELECT titel, inhalt FROM seiten_inhalte WHERE slug = ?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<h2>" . htmlspecialchars($row['titel']) . "</h2>";
    echo "<p>" . nl2br(htmlspecialchars($row['inhalt'])) . "</p>";
} else {
    echo "<h2>Seite nicht gefunden</h2>";
    echo "<p>Der angeforderte Inhalt konnte nicht gefunden werden.</p>";
}

$stmt->close();
$conn->close();
?>