<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alpine.js PHP MySQL One-Page</title>
    <!-- Alpine.js über CDN einbinden -->
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin=""/>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    

    <div x-data="{
        currentPage: 'seite1',
        pageContent: '',
        isLoading: false,
        mainMenu: [],
        secondaryMenu: [],
        activeSubmenus: {}
    }"
         x-init="
           /* console.log('Alpine.js x-init block started.'); */
            /* console.log('Initial activeSubmenus:', activeSubmenus); */

            loadPage = async (pageSlug) => {
                isLoading = true;
                try {
                    const response = await fetch(`get_page_content.php?slug=${pageSlug}`);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    pageContent = await response.text();
                    currentPage = pageSlug;
                } catch (error) {
                    console.error('Fehler beim Laden der Seite:', error);
                    pageContent = '<p style=&quot;color: red;&quot;>Fehler beim Laden des Inhalts.</p>';
                } finally {
                    isLoading = false;
                }
            };

            loadMenu = async () => {
                try {
                    const response = await fetch('get_menu_data.php');
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const data = await response.json();
                    mainMenu = data.mainMenu || [];
                    secondaryMenu = data.secondaryMenu || [];
                    /* console.log('Menu loaded. mainMenu:', mainMenu); */
                    /* console.log('Menu loaded. secondaryMenu:', secondaryMenu); */
                } catch (error) {
                    console.error('Fehler beim Laden des Menüs:', error);
                }
            };

            toggleSubmenu = (itemId) => {
                activeSubmenus[itemId] = !activeSubmenus[itemId];
                /* console.log('toggleSubmenu called for ID:', itemId, 'New state:', activeSubmenus[itemId]); */
                /* console.log('Current activeSubmenus state:', activeSubmenus); */
            };

            loadPage(currentPage);
            loadMenu();
            /* console.log('Alpine.js x-init block finished.'); */
         ">

        <!-- Hauptmenü (Oben) -->
        <nav>
            <ul x-data>
                <template x-for="item in mainMenu" :key="item.id">
                    <li :class="{ 'has-children': item.children && item.children.length > 0 }"
                        @mouseenter="
                            /* console.log('Mouse entered item ID:', item.id); // NEU: Log für Mouseenter */
                            item.children && item.children.length > 0 ? $data.activeSubmenus[item.id] = true : null
                        "
                        @mouseleave="
                            /* console.log('Mouse left item ID:', item.id); // NEU: Log für Mouseleave */
                            item.children && item.children.length > 0 ? $data.activeSubmenus[item.id] = false : null
                        ">
                        <a href="#" @click.prevent="item.target_type === 'page' ? loadPage(item.slug) : window.open(item.slug, '_blank')"
                           :class="{ 'active': currentPage === item.slug }">
                            <template x-if="item.icon_url">
                                <img :src="item.icon_url" :alt="item.label + ' Icon'" class="menu-icon">
                            </template>
                            <span x-text="item.label"></span>
                        </a>

                        <!-- Erste Unterebene für Hauptmenü -->
                        <template x-if="item.children && item.children.length > 0">
                            <ul class="submenu"
                                :class="{ 'show': activeSubmenus[item.id] }"
                                x-show="activeSubmenus[item.id]"
                                x-transition:enter="transition ease-out duration-300"
                                x-transition:enter-start="opacity-0 transform scale-90"
                                x-transition:enter-end="opacity-100 transform scale-100"
                                x-transition:leave="transition ease-in duration-200"
                                x-transition:leave-start="opacity-100 transform scale-100"
                                x-transition:leave-end="opacity-0 transform scale-90">
                                <template x-for="subItem1 in item.children" :key="subItem1.id">
                                    <li :class="{ 'has-children': subItem1.children && subItem1.children.length > 0 }"
                                        @mouseenter="
                                            /* console.log('Mouse entered subItem1 ID:', subItem1.id); // NEU: Log für Subitem Mouseenter */
                                            subItem1.children && subItem1.children.length > 0 ? $data.activeSubmenus[subItem1.id] = true : null
                                        "
                                        @mouseleave="
                                            /* console.log('Mouse left subItem1 ID:', subItem1.id); // NEU: Log für Subitem Mouseleave */
                                            subItem1.children && subItem1.children.length > 0 ? $data.activeSubmenus[subItem1.id] = false : null
                                        ">
                                        <a href="#" @click.prevent="subItem1.target_type === 'page' ? loadPage(subItem1.slug) : window.open(subItem1.slug, '_blank')"
                                           :class="{ 'active': currentPage === subItem1.slug }">
                                            <template x-if="subItem1.icon_url">
                                                <img :src="subItem1.icon_url" :alt="subItem1.label + ' Icon'" class="menu-icon">
                                            </template>
                                            <span x-text="subItem1.label"></span>
                                        </a>

                                        <!-- Zweite Unterebene für Hauptmenü -->
                                        <template x-if="subItem1.children && subItem1.children.length > 0">
                                            <ul class="submenu"
                                                :class="{ 'show': activeSubmenus[subItem1.id] }"
                                                x-show="activeSubmenus[subItem1.id]"
                                                x-transition:enter="transition ease-out duration-300"
                                                x-transition:enter-start="opacity-0 transform scale-90"
                                                x-transition:enter-end="opacity-100 transform scale-100"
                                                x-transition:leave="transition ease-in duration-200"
                                                x-transition:leave-start="opacity-100 transform scale-100"
                                                x-transition:leave-end="opacity-0 transform scale-90">
                                                <template x-for="subItem2 in subItem1.children" :key="subItem2.id">
                                                    <li>
                                                        <a href="#" @click.prevent="subItem2.target_type === 'page' ? loadPage(subItem2.slug) : window.open(subItem2.slug, '_blank')"
                                                           :class="{ 'active': currentPage === subItem2.slug }">
                                                            <template x-if="subItem2.icon_url">
                                                                <img :src="subItem2.icon_url" :alt="subItem2.label + ' Icon'" class="menu-icon">
                                                            </template>
                                                            <span x-text="subItem2.label"></span>
                                                        </a>
                                                    </li>
                                                </template>
                                            </ul>
                                        </template>
                                    </li>
                                </template>
                            </ul>
                        </template>
                    </li>
                </template>
            </ul>
        </nav>

        <div class="content-area">
            <template x-if="isLoading">
                <p class="loading">Inhalt wird geladen...</p>
            </template>
            <template x-if="!isLoading" x-html="pageContent">
                <!-- Der geladene Inhalt wird hier eingefügt -->
            </template>
        </div>

        <!-- Zweite Menüreihe (Unten) -->
        <footer class="footer-nav">

            <nav>
                <ul x-data>
                    <template x-for="item in secondaryMenu" :key="item.id">
                        <li>
                            <a href="#" @click.prevent="item.target_type === 'page' ? loadPage(item.slug) : window.open(item.slug, '_blank')"
                               :class="{ 'active': currentPage === item.slug, [item.css_class]: item.css_class }">
                                <template x-if="item.icon_url">
                                    <img :src="item.icon_url" :alt="item.label + ' Icon'" class="menu-icon">
                                </template>
                                <span x-text="item.label"></span>
                            </a>
                        </li>
                    </template>
                </ul>
            </nav>
        </footer>

    </div>

</body>
</html>