<!-- Wird vollständig ersetzt durch loadedHtml -->
<p>Dies ist Standardinhalt aus der Datenbank.</p>