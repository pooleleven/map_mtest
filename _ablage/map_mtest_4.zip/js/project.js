console.log('include_id:', window.include_id);

function menuComponent() {
    return {
        menu: { top: [], bottom: [] },
        content: '',
        pageTitle: '',
        includeFile: '',
        dynamicModule: '',
        loadedHtml: '',
        activeSlug: '',

        async init() {
            const res = await fetch('get_menu_data.php');
            this.menu = await res.json();
        },

   async loadPage(slug) {
    this.pageTitle = '';
    this.loadedHtml = '';
    this.includeFile = '';
    this.dynamicModule = '';
    this.content = '';
    this.activeSlug = slug;

    try {
        // 1. Metadaten zur Seite
        const res = await fetch('get_page_content.php?slug=' + encodeURIComponent(slug));
        const data = await res.json();
        this.pageTitle = data.titel;
        this.includeFile = data.include_file;
        this.dynamicModule = data.js_module || null;

        // 2. HTML laden
        const htmlRes = await fetch('includes/' + this.includeFile);
        console.log('set loadedHtml');
        this.loadedHtml = await htmlRes.text();

        // 3. JS-Modul ggf. nachladen
        console.log('starting script load');
        let scriptPromise = Promise.resolve();
        if (this.dynamicModule === 'gridComponent') {
            scriptPromise = new Promise(resolve => loadScript('js/gridComponent.js', resolve));
        }
        await scriptPromise;
        console.log('script loaded', typeof window.gridComponent);

        // 4. Jetzt Alpine für den neuen Bereich initialisieren
        Promise.resolve().then(() => {
            const area = document.querySelector('.content-area');
            console.log('Alpine.initTree ausgeführt');
            if (area) Alpine.initTree(area);
        });

    } catch (err) {
        this.pageTitle = 'Fehler';
        this.loadedHtml = '<p>Fehler beim Laden der Seite.</p>';
        console.error(err);
    }
}






    };
}

window.menuComponent = menuComponent;

function loadScript(src, callback) {
  // Lädt ein externes JS-Modul dynamisch nach
  const script = document.createElement('script');
  script.src = src;
  script.onload = callback;
  document.head.appendChild(script);
}

document.addEventListener('alpine:init', () => {
    Alpine.data('menuComponent', menuComponent);
});






