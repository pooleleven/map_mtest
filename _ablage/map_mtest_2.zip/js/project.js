console.log('include_id:', window.include_id);

function menuComponent() {
    return {
        menu: { top: [], bottom: [] },
        content: '',
        pageTitle: '',
        includeFile: '',
        dynamicModule: '',
        loadedHtml: '',

        async init() {
            const res = await fetch('get_menu_data.php');
            this.menu = await res.json();
        },

        async loadPage(slug) {
            this.pageTitle = '';
            this.loadedHtml = '';
            this.includeFile = '';
            this.dynamicModule = '';
            this.content = '';

            try {
                const res = await fetch('get_page_content.php?slug=' + encodeURIComponent(slug));
                const data = await res.json();
                this.pageTitle = data.titel;
                this.includeFile = data.include_file;
                this.dynamicModule = data.js_module || null;

                // Lade HTML-Content (Include-Datei dynamisch laden)
                const htmlRes = await fetch('includes/' + this.includeFile);
                this.loadedHtml = await htmlRes.text();
            } catch (err) {
                this.pageTitle = 'Fehler';
                this.loadedHtml = '<p>Fehler beim Laden der Seite.</p>';
                console.error(err);
            }
            this.activeSlug = slug;
        }
        
    };
}

window.menuComponent = menuComponent;

// project.js
function loadScript(src, callback) {
  const script = document.createElement('script');
  script.src = src;
  script.onload = callback;
  document.head.appendChild(script);
}


// Annahme: window.include_id ist von PHP gesetzt!
document.addEventListener('DOMContentLoaded', function() {
  if (window.include_id === 'appcontent_a') {
    loadScript('js/gridComponent.js', function() {
      if (window.initGridComponent) window.initGridComponent();
    });
  } else if (window.include_id === 'appcontent_b') {
    loadScript('js/mapComponent.js', function() {
      if (window.initMapComponent) window.initMapComponent();
    });
  }
});



document.addEventListener('alpine:init', () => {
    Alpine.data('menuComponent', menuComponent);
});



