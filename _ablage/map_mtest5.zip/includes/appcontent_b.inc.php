<div class="content-area">
    <template x-if="content">
        <div>
            <h2 x-text="pageTitle"></h2>
            <div x-html="content"></div>
        </div>
    </template>
</div>