function menuComponent() {
    return {
        menu: { top: [], bottom: [] },
        activeSlug: '',
        includeFile: '',
        dynamicModule: null,
        loadedHtml: '',
        pageTitle: '',

        async init() {
            const res = await fetch('get_menu_data.php');
            this.menu = await res.json();
        },

        async loadPage(slug) {
            this.activeSlug = slug;
            this.includeFile = '';
            this.loadedHtml = '';
            this.dynamicModule = null;
            this.pageTitle = '';

            try {
                const res = await fetch('get_page_content.php?slug=' + encodeURIComponent(slug));
                const data = await res.json();

                if (!data.include_file) {
                    this.loadedHtml = '<p>Kein Inhalt verfügbar</p>';
                    return;
                }

                this.includeFile = 'includes/' + data.include_file;
                this.dynamicModule = data.js_module || null; // <== robuster gegen leere Werte
                this.pageTitle = data.titel;

                const htmlRes = await fetch(this.includeFile);
                this.loadedHtml = await htmlRes.text();
            } catch (err) {
                console.error('Fehler beim Laden der Seite:', err);
                this.loadedHtml = '<p>Fehler beim Laden</p>';
            }
        }
    };
}

function gridComponent() {
    return {
        objects: [],

        async init() {
            try {
                const res = await fetch('get_appdata.php?app=objects');
                this.objects = await res.json();
            } catch (err) {
                console.error('Fehler beim Laden der Objekte:', err);
            }
        },

        async save(obj) {
            try {
                const res = await fetch('save_object.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(obj)
                });
                const result = await res.json();
                if (result.success) {
                    alert('Objekt gespeichert');
                } else {
                    alert('Fehler beim Speichern: ' + (result.error || 'unbekannter Fehler'));
                }
            } catch (err) {
                console.error('Fehler beim Speichern:', err);
                alert('Fehler beim Speichern');
            }
        }
    };
}

// Platzhalter für mögliche Erweiterungen (z. B. mapComponent)
function mapComponent() {
    return {
        async init() {
            console.log('mapComponent init – Beispiel für eine andere App-Komponente');
        }
    };
}
