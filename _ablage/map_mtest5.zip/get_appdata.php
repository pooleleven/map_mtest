<?php
require_once("global_vars.inc.php");
header('Content-Type: application/json');

if (!isset($_GET['app'])) {
    echo json_encode(['error' => 'Parameter \"app\" fehlt.']);
    exit;
}

$app = $_GET['app'];

switch ($app) {
    case 'objects':
        $sql = "SELECT id, name, description, latitude, longitude FROM objects ORDER BY id ASC";
        $result = $conn->query($sql);
        if (!$result) {
            http_response_code(500);
            echo json_encode(['error' => $conn->error]);
            exit;
        }
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
        break;

    // Beispiel für später:
    case 'users':
        echo json_encode([['id' => 1, 'name' => 'Admin']]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unbekannter App-Typ']);
        break;
}
