function menuComponent() {
    return {
        menu: { top: [1,2,3], bottom: [] },
        async init() { console.log("Alpine init läuft!"); }
    };
}
window.menuComponent = menuComponent;
document.addEventListener('alpine:init', () => {
    Alpine.data('menuComponent', menuComponent);
});
console.log('project.js geladen');