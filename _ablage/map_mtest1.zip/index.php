<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alpine.js PHP MySQL One-Page</title>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h1>Meine Alpine.js One-Page-Solution</h1>

    <div x-data="{
        currentPage: 'seite1',
        pageContent: '',
        isLoading: false,
        mainMenu: [], // Hier werden die Hauptmenüdaten gespeichert
        secondaryMenu: [], // Hier werden die Daten für die untere Menüleiste gespeichert
        activeSubmenus: {} // Für die Verwaltung von geöffneten/geschlossenen Untermenüs bei Klick

    }"
         x-init="
            // Funktion zum Laden des Inhalts
            loadPage = async (pageSlug) => {
                isLoading = true;
                try {
                    const response = await fetch(`get_page_content.php?slug=${pageSlug}`);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    pageContent = await response.text();
                    currentPage = pageSlug; // Setzt die aktuelle Seite nur bei Erfolg
                } catch (error) {
                    console.error('Fehler beim Laden der Seite:', error);
                    pageContent = '<p style=&quot;color: red;&quot;>Fehler beim Laden des Inhalts.</p>';
                } finally {
                    isLoading = false;
                }
            };

            // Funktion zum Laden der Menüdaten
            loadMenu = async () => {
                try {
                    const response = await fetch('get_menu_data.php');
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const data = await response.json();
                    // NEU: Daten aus dem JSON-Objekt den richtigen Menüs zuweisen
                    mainMenu = data.mainMenu || [];
                    secondaryMenu = data.secondaryMenu || [];

                } catch (error) {
                    console.error('Fehler beim Laden des Menüs:', error);
                }
            };

            // Funktion zum Umschalten von Untermenüs (falls per Klick)
            toggleSubmenu = (itemId) => {
                activeSubmenus[itemId] = !activeSubmenus[itemId];
            };

            // Initialen Inhalt und Menü laden
            loadPage(currentPage);
            loadMenu();
         ">

        <!-- Hauptmenü (Oben) -->
        <nav>
            <ul x-data>
                <template x-for="item in mainMenu" :key="item.id">
                    <li :class="{ 'has-children': item.children && item.children.length > 0 }"
                        @mouseenter="item.children && item.children.length > 0 ? $data.activeSubmenus[item.id] = true : null"
                        @mouseleave="item.children && item.children.length > 0 ? $data.activeSubmenus[item.id] = false : null">
                        <a href="#" @click.prevent="item.target_type === 'page' ? loadPage(item.slug) : window.open(item.slug, '_blank')"
                           :class="{ 'active': currentPage === item.slug }">
                            <template x-if="item.icon_url">
                                <img :src="item.icon_url" :alt="item.label + ' Icon'" class="menu-icon">
                            </template>
                            <span x-text="item.label"></span>
                        </a>

                        <!-- Erste Unterebene für Hauptmenü -->
                        <template x-if="item.children && item.children.length > 0">
                            <ul class="submenu"
                                :class="{ 'show': activeSubmenus[item.id] }"
                                x-show="activeSubmenus[item.id]"
                                x-transition:enter="transition ease-out duration-300"
                                x-transition:enter-start="opacity-0 transform scale-90"
                                x-transition:enter-end="opacity-100 transform scale-100"
                                x-transition:leave="transition ease-in duration-200"
                                x-transition:leave-start="opacity-100 transform scale-100"
                                x-transition:leave-end="opacity-0 transform scale-90">
                                <template x-for="subItem1 in item.children" :key="subItem1.id">
                                    <li :class="{ 'has-children': subItem1.children && subItem1.children.length > 0 }"
                                        @mouseenter="subItem1.children && subItem1.children.length > 0 ? $data.activeSubmenus[subItem1.id] = true : null"
                                        @mouseleave="subItem1.children && subItem1.children.length > 0 ? $data.activeSubmenus[subItem1.id] = false : null">
                                        <a href="#" @click.prevent="subItem1.target_type === 'page' ? loadPage(subItem1.slug) : window.open(subItem1.slug, '_blank')"
                                           :class="{ 'active': currentPage === subItem1.slug }">
                                            <template x-if="subItem1.icon_url">
                                                <img :src="subItem1.icon_url" :alt="subItem1.label + ' Icon'" class="menu-icon">
                                            </template>
                                            <span x-text="subItem1.label"></span>
                                        </a>

                                        <!-- Zweite Unterebene für Hauptmenü -->
                                        <template x-if="subItem1.children && subItem1.children.length > 0">
                                            <ul class="submenu"
                                                :class="{ 'show': activeSubmenus[subItem1.id] }"
                                                x-show="activeSubmenus[subItem1.id]"
                                                x-transition:enter="transition ease-out duration-300"
                                                x-transition:enter-start="opacity-0 transform scale-90"
                                                x-transition:enter-end="opacity-100 transform scale-100"
                                                x-transition:leave="transition ease-in duration-200"
                                                x-transition:leave-start="opacity-100 transform scale-100"
                                                x-transition:leave-end="opacity-0 transform scale-90">
                                                <template x-for="subItem2 in subItem1.children" :key="subItem2.id">
                                                    <li>
                                                        <a href="#" @click.prevent="subItem2.target_type === 'page' ? loadPage(subItem2.slug) : window.open(subItem2.slug, '_blank')"
                                                           :class="{ 'active': currentPage === subItem2.slug }">
                                                            <template x-if="subItem2.icon_url">
                                                                <img :src="subItem2.icon_url" :alt="subItem2.label + ' Icon'" class="menu-icon">
                                                            </template>
                                                            <span x-text="subItem2.label"></span>
                                                        </a>
                                                    </li>
                                                </template>
                                            </ul>
                                        </template>
                                    </li>
                                </template>
                            </ul>
                        </template>
                    </li>
                </template>
            </ul>
        </nav>

        <div class="content-area">
            <template x-if="isLoading">
                <p class="loading">Inhalt wird geladen...</p>
            </template>
            <template x-if="!isLoading" x-html="pageContent">
                <!-- Der geladene Inhalt wird hier eingefügt -->
            </template>
        </div>

        <!-- Zweite Menüreihe (Unten) -->
        <footer class="footer-nav">
            <h2>Zweite Menüreihe</h2>
            <nav>
                <ul x-data>
                    <template x-for="item in secondaryMenu" :key="item.id">
                        <li>
                            <!-- Für die untere Leiste gehen wir davon aus, dass es keine Untermenüs gibt
                                 und die Links direkt zu Seiten oder externen URLs führen.
                                 Wenn du auch hier Untermenüs möchtest, müsstest du die Logik
                                 vom Hauptmenü hierher kopieren und anpassen. -->
                            <a href="#" @click.prevent="item.target_type === 'page' ? loadPage(item.slug) : window.open(item.slug, '_blank')"
                               :class="{ 'active': currentPage === item.slug, [item.css_class]: item.css_class }">
                                <template x-if="item.icon_url">
                                    <img :src="item.icon_url" :alt="item.label + ' Icon'" class="menu-icon">
                                </template>
                                <span x-text="item.label"></span>
                            </a>
                        </li>
                    </template>
                </ul>
            </nav>
        </footer>

    </div>

</body>
</html>