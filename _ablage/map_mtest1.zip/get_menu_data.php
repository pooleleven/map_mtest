<?php
include 'global_vars.inc.php'; // Deine DB-Verbindung

header('Content-Type: application/json; charset=utf-8');

$stmt = $conn->prepare("SELECT id, parent_id, position, label, slug, icon_url, css_class, target_type FROM menu_items ORDER BY position ASC, parent_id ASC, sort_order ASC");
$stmt->execute();
$result = $stmt->get_result();

$itemsByPosition = [
    1 => [], // Für Hauptmenü (Position 1)
    2 => []  // Für untere Menüleiste (Position 2)
];

while ($row = $result->fetch_assoc()) {
    // Stellen Sie sicher, dass die Position gültig ist, bevor Sie sie hinzufügen
    if (isset($itemsByPosition[$row['position']])) {
        $itemsByPosition[$row['position']][] = $row;
    }
}

// Funktion zum Aufbau der hierarchischen Menüstruktur
function buildTree(array &$elements, $parentId = NULL) {
    $branch = [];
    foreach ($elements as &$element) {
        // Wichtig: Hier prüfen wir auf den parent_id, der in der aktuellen Untermenge liegt
        if ($element['parent_id'] == $parentId) {
            $children = buildTree($elements, $element['id']);
            if ($children) {
                $element['children'] = array_values($children); // array_values für sauberes JSON
            }
            $branch[$element['id']] = $element;
            // unset($element); // Kann hier zu Problemen führen, wenn $elements als Referenz übergeben wird und in weiteren Schleifen benötigt wird. Besser ist es, die Elemente nicht zu unsetten, wenn sie in der buildTree-Funktion mehrfach referenziert werden könnten.
        }
    }
    return $branch;
}

$mainMenuTree = buildTree($itemsByPosition[1], NULL);
$secondaryMenuTree = buildTree($itemsByPosition[2], NULL); // Auch hier einen Baum aufbauen, falls Untermenüs gewünscht sind

// Gib beide Menübäume als ein JSON-Objekt zurück
echo json_encode([
    'mainMenu' => array_values($mainMenuTree),
    'secondaryMenu' => array_values($secondaryMenuTree)
]);

$stmt->close();
$conn->close();
?>